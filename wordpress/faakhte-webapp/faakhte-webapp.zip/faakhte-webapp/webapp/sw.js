/* Faakhte web app service worker */
const V='faakhte-202611281800';
const CORE=['./','index.html','manifest.json','icon-192.png','icon-512.png','apple-touch-icon.png',"img/m00.jpg","img/m01.jpg","img/m02.jpg","img/m03.jpg","img/m04.jpg","img/m05.jpg","img/m06.jpg","img/m07.jpg","img/m08.jpg","img/m09.jpg","img/m10.jpg","img/m11.jpg","img/m12.jpg"];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request; if(r.method!=='GET')return; const u=new URL(r.url);
  if(u.origin!==location.origin||!u.pathname.startsWith('/faakhte/'))return;
  const netFirst=r.mode==='navigate'||u.pathname.endsWith('.json')||u.pathname.endsWith('.html')||u.pathname.endsWith('/');
  if(netFirst){e.respondWith(fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(V).then(c=>c.put(r,cp))}return res}).catch(()=>caches.match(r).then(m=>m||caches.match('index.html'))));return}
  e.respondWith(caches.match(r).then(m=>m||fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(V).then(c=>c.put(r,cp))}return res})));
});
